<tr class="customer_row" data-row_index="<?php echo e($row_count, false); ?>">
	<td class="serial_no" ></td>
	<!-- <td><?php echo e($contact->contact_id, false); ?></td> -->
	<input type="hidden" 
	name="customers[<?php echo e($row_count, false); ?>][contact_id]" 
	value="<?php echo e($contact->id, false); ?>">
    <td><?php echo e($contact->name, false); ?></td>
    <td><?php echo e($contact->address_line_1, false); ?></td>
    <td><?php echo e($contact->mobile, false); ?></td>
	<td class="text-center v-center">
		<i class="fa fa-times text-danger pos_remove_row cursor-pointer" aria-hidden="true"></i>
	</td>
</tr><?php /**PATH C:\laragon\www\resources\views/sales_admin/customer_row.blade.php ENDPATH**/ ?>