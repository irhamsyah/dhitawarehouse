<div class="modal-dialog" role="document">
	<?php echo Form::open(['url' => action([\App\Http\Controllers\SalesAdminController::class, 'updateSalesmanTarget'], [$salesman_target->id]), 'method' => 'put', 'id' => 'edit_sales_target_form' ]); ?>

	<div class="modal-content">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			<h4 class="modal-title"><?php echo app('translator')->get('Edit Target Penjualan'); ?> - <?php echo e($salesman_target->sales_name ?? '-', false); ?> </h4>
		</div>
		<div class="modal-body">
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<?php echo Form::label('sales_target', __('lang_v1.sales_target') . ':'); ?>

						<?php
							$sales_target = isset($salesman_target->sales_target) ? number_format($salesman_target->sales_target, 0) : 0;
						?>
						<?php echo Form::text('sales_target', $sales_target, ['class' => 'form-control input_number', 'placeholder' => __('lang_v1.sales_target')]); ?>

					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<?php echo Form::label('remaining_target', __('sales_admin.remaining_target') . ':'); ?>

						<?php
							$remaining_target = isset($salesman_target->remaining_target) ? number_format($salesman_target->remaining_target) : 0;
						?>
						<?php echo Form::text('remaining_target', $remaining_target, ['class' => 'form-control input_number', 'placeholder' => __('sales_admin.remaining_target')]); ?>

					</div>
				</div>
			</div>

			
		</div>
		<div class="modal-footer">
			<button type="submit" class="tw-dw-btn tw-dw-btn-primary tw-text-white"><?php echo app('translator')->get('messages.update'); ?></button>
		    <button type="button" class="tw-dw-btn tw-dw-btn-neutral tw-text-white" data-dismiss="modal"><?php echo app('translator')->get('messages.cancel'); ?></button>
		</div>
		<?php echo Form::close(); ?>

	</div><!-- /.modal-content -->
</div><!-- /.modal-dialog --><?php /**PATH C:\laragon\www\resources\views/sales_admin/partials/edit_salesman_target.blade.php ENDPATH**/ ?>