<?php if(empty($only) || in_array('sell_list_filter_date_range', $only)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('sell_list_filter_date_range', __('report.date_range') . ':'); ?>

        <?php echo Form::text('sell_list_filter_date_range', null, ['placeholder' => __('lang_v1.select_a_date_range'), 'class' => 'form-control', 'readonly']); ?>

    </div>
</div>
<?php endif; ?>
<?php if((empty($only) || in_array('created_by', $only)) && !empty($sales_representative)): ?>
<div class="col-md-3">
    <div class="form-group">
        <?php echo Form::label('created_by',  __('Nama Sales') . ':'); ?>

        <?php echo Form::select('created_by', $sales_representative, null, ['class' => 'form-control select2', 'style' => 'width:100%']); ?>

    </div>
</div>
<?php endif; ?><?php /**PATH C:\laragon\www\resources\views/sales_admin/partials/visit_list_filters.blade.php ENDPATH**/ ?>